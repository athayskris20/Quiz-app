export interface Question {
  id: string;
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  answer: 'A' | 'B' | 'C' | 'D';
  explanation: string;
  tag: string;
  subject: string;
}

export interface QuizResult {
  id: string;
  subject: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  date: string;
  timeSpent: number;
  questions: Question[];
  userAnswers: ('A' | 'B' | 'C' | 'D' | null)[];
}

export type Subject = 
  | 'Anatomy'
  | 'Biochemistry'
  | 'Community Medicine'
  | 'Forensic Medicine'
  | 'ENT'
  | 'Ophthalmology'
  | 'Microbiology'
  | 'Neurology'
  | 'Cardiology'
  | 'Pulmonology'
  | 'Gastroenterology & Hepatology'
  | 'Nephrology'
  | 'Hematology'
  | 'Rheumatology'
  | 'Endocrinology'
  | 'General Medicine'
  | 'Surgery'
  | 'Paediatrics'
  | 'Orthopedics'
  | 'Dermatology'
  | 'Psychiatry'
  | 'Anaesthesia';