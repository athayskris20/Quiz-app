import { Subject } from '../types';

export const SUBJECTS: Subject[] = [
  'Anatomy',
  'Biochemistry',
  'Community Medicine',
  'Forensic Medicine',
  'ENT',
  'Ophthalmology',
  'Microbiology',
  'Neurology',
  'Cardiology',
  'Pulmonology',
  'Gastroenterology & Hepatology',
  'Nephrology',
  'Hematology',
  'Rheumatology',
  'Endocrinology',
  'General Medicine',
  'Surgery',
  'Paediatrics',
  'Orthopedics',
  'Dermatology',
  'Psychiatry',
  'Anaesthesia'
];