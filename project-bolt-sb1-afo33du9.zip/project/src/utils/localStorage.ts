import { Question, QuizResult } from '../types';

const QUESTIONS_KEY = 'neet_pg_questions';
const RESULTS_KEY = 'neet_pg_results';

export function saveQuestions(questions: Question[]): void {
  const existingQuestions = getStoredQuestions();
  const allQuestions = [...existingQuestions, ...questions];
  localStorage.setItem(QUESTIONS_KEY, JSON.stringify(allQuestions));
}

export function getStoredQuestions(): Question[] {
  try {
    const stored = localStorage.getItem(QUESTIONS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading questions:', error);
    return [];
  }
}

export function getQuestionsBySubject(subject: string): Question[] {
  const questions = getStoredQuestions();
  return questions.filter(q => q.subject === subject);
}

export function getQuestionsByTags(subject: string, tags: string[]): Question[] {
  const questions = getQuestionsBySubject(subject);
  if (tags.length === 0) return questions;
  return questions.filter(q => tags.includes(q.tag));
}

export function getUniqueTagsBySubject(subject: string): string[] {
  const questions = getQuestionsBySubject(subject);
  const tags = questions.map(q => q.tag);
  return Array.from(new Set(tags)).sort();
}

export function saveQuizResult(result: QuizResult): void {
  const existingResults = getQuizResults();
  existingResults.push(result);
  localStorage.setItem(RESULTS_KEY, JSON.stringify(existingResults));
}

export function getQuizResults(): QuizResult[] {
  try {
    const stored = localStorage.getItem(RESULTS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading quiz results:', error);
    return [];
  }
}

export function getResultsBySubject(subject: string): QuizResult[] {
  const results = getQuizResults();
  return results.filter(r => r.subject === subject);
}