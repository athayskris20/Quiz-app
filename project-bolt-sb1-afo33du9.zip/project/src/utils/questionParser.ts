import { Question, Subject } from '../types';

export function parseQuestions(input: string, subject: Subject): Question[] {
  const questions: Question[] = [];
  
  // Clean and normalize the input - more robust cleaning
  const cleanInput = input
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/\u00A0/g, ' ') // Replace non-breaking spaces
    .replace(/\s+/g, ' ') // Normalize multiple spaces
    .trim();
  
  // Split by [START Q] and filter out empty strings
  const questionBlocks = cleanInput.split(/\[\s*START\s+Q\s*\]/i).filter(block => block.trim());
  
  for (const block of questionBlocks) {
    try {
      // Remove [END Q] if present
      const cleanBlock = block.replace(/\[\s*END\s+Q\s*\]/i, '').trim();
      
      if (!cleanBlock) continue;
      
      const question = parseQuestionBlock(cleanBlock, subject);
      if (question) {
        questions.push(question);
      }
    } catch (error) {
      console.warn('Failed to parse question block:', error);
    }
  }
  
  return questions;
}

function parseQuestionBlock(block: string, subject: Subject): Question | null {
  const lines = block.split('\n')
    .map(line => line.trim())
    .filter(line => line);
  
  const questionData: Partial<Question> = {
    id: generateId(),
    subject
  };
  
  for (const line of lines) {
    const colonIndex = line.indexOf(':');
    if (colonIndex === -1) continue;
    
    const key = line.substring(0, colonIndex)
      .trim()
      .toLowerCase()
      .replace(/\s+/g, '')
      .replace(/[^\w]/g, ''); // Remove non-word characters
    const value = line.substring(colonIndex + 1).trim();
    
    switch (key) {
      case 'question':
        questionData.question = value;
        break;
      case 'optiona':
        questionData.optionA = value;
        break;
      case 'optionb':
        questionData.optionB = value;
        break;
      case 'optionc':
        questionData.optionC = value;
        break;
      case 'optiond':
        questionData.optionD = value;
        break;
      case 'd':
      case 'optiond':
      case 'choiced':
      case 'answerd':
        questionData.optionD = value;
        break;
      case 'answer':
        const answer = value.toUpperCase().trim();
        if (['A', 'B', 'C', 'D'].includes(answer)) {
          questionData.answer = answer as 'A' | 'B' | 'C' | 'D';
        }
        break;
      case 'explanation':
        questionData.explanation = value;
        break;
      case 'tag':
        questionData.tag = value;
        break;
    }
  }
  
  // Validate required fields
  if (questionData.question && 
      questionData.optionA && 
      questionData.optionB && 
      questionData.optionC && 
      questionData.optionD && 
      questionData.answer && 
      questionData.explanation && 
      questionData.tag) {
    return questionData as Question;
  }
  
  return null;
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}