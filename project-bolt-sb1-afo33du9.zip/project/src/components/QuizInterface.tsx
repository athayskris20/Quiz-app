import React, { useState, useEffect } from 'react';
import { Subject, Question } from '../types';
import { getQuestionsBySubject } from '../utils/localStorage';
import { ArrowLeft, Play, Clock } from 'lucide-react';
import QuizRunner from './QuizRunner';

interface QuizInterfaceProps {
  subject: Subject;
  onBack: () => void;
}

function QuizInterface({ subject, onBack }: QuizInterfaceProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [showQuiz, setShowQuiz] = useState(false);
  const [numberOfQuestions, setNumberOfQuestions] = useState(10);

  useEffect(() => {
    const availableQuestions = getQuestionsBySubject(subject);
    setQuestions(availableQuestions);
  }, [subject]);

  const startQuiz = () => {
    if (questions.length === 0) return;
    setShowQuiz(true);
  };

  const getRandomQuestions = (count: number): Question[] => {
    const shuffled = [...questions].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, Math.min(count, questions.length));
  };

  if (showQuiz) {
    return (
      <QuizRunner
        questions={getRandomQuestions(numberOfQuestions)}
        subject={subject}
        onComplete={() => setShowQuiz(false)}
        onBack={() => setShowQuiz(false)}
      />
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-slate-600 hover:text-slate-800 transition-colors mr-4"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>
        <h1 className="text-2xl font-bold text-slate-800">
          {subject} Quiz
        </h1>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
        <div className="text-center mb-8">
          <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Play className="w-8 h-8 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Ready to Start Quiz?</h2>
          <p className="text-slate-600 mb-6">
            Test your knowledge with challenging NEET PG level questions
          </p>
        </div>

        <div className="max-w-md mx-auto space-y-6">
          <div className="bg-slate-50 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-slate-700">Available Questions:</span>
              <span className="text-sm font-bold text-blue-600">{questions.length}</span>
            </div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-slate-700">Time per Question:</span>
              <span className="text-sm text-slate-600 flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                <span className="font-bold">45 seconds</span>
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-700">Subject:</span>
              <span className="text-sm font-bold text-slate-800">{subject}</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Number of Questions:
            </label>
            <select
              value={numberOfQuestions}
              onChange={(e) => setNumberOfQuestions(Number(e.target.value))}
              className="w-full p-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {[5, 10, 15, 20, 25, 30].filter(n => n <= questions.length).map(n => (
                <option key={n} value={n}>{n} Questions</option>
              ))}
              {questions.length < 30 && questions.length > 0 && (
                <option value={questions.length}>All {questions.length} Questions</option>
              )}
            </select>
          </div>

          <button
            onClick={startQuiz}
            disabled={questions.length === 0}
            className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
          >
            {questions.length === 0 ? 'No Questions Available' : `Start ${numberOfQuestions} Question Quiz`}
          </button>

          {questions.length === 0 && (
            <p className="text-center text-sm text-slate-600 mt-4">
              No questions found for this subject. Please add some questions first.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default QuizInterface;