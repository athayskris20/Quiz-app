import React, { useState } from 'react';
import { Subject } from '../types';
import { parseQuestions } from '../utils/questionParser';
import { saveQuestions } from '../utils/localStorage';
import { ArrowLeft, Save, AlertCircle, CheckCircle, Copy } from 'lucide-react';

interface QuestionInputProps {
  subject: Subject;
  onBack: () => void;
}

function QuestionInput({ subject, onBack }: QuestionInputProps) {
  const [input, setInput] = useState('');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [parsedCount, setParsedCount] = useState(0);
  const [isRealTimeParsing, setIsRealTimeParsing] = useState(false);

  const generatePrompt = () => {
    return `Generate xxx multiple choice questions for a NEET PG level medical quiz on the topic of: ${subject}

**CRITICAL INSTRUCTIONS: Follow this format EXACTLY. Do not deviate.**

For each question, use the following strict structure:

[START Q]
QUESTION: [Your question text here]
OPTION A: [Text for option A]
OPTION B: [Text for option B]
OPTION C: [Text for option C]
OPTION D: [Text for option D]
ANSWER: [A single letter: A, B, C, or D]
EXPLANATION: [Your explanation text here]
TAG: [A tag or subtopic related to question]
[END Q]

Example:
[START Q]
QUESTION: A 2-month-old infant presents with jaundice, hepatomegaly, and an oil drop cataract. Urine is positive for reducing substances, but a glucose oxidase dipstick test is negative. Which of the following is the most likely accumulated toxic substance?
OPTION A: Galactose-1-phosphate
OPTION B: Galactokinase
OPTION C: Glucose-6-phosphate
OPTION D: Glucocerebroside
ANSWER: A
EXPLANATION: The clinical features are classic for galactosemia, caused by GALT deficiency, leading to the accumulation of galactose-1-phosphate.
TAG: galactosemia
[END Q]

Further Rules:
1. Question Types: Focus on clinical scenarios or image (explanatory) based questions covering etiology, clinical features, diagnostic features, investigation and its features, treatment, side effects, and complications.
2. Difficulty & Choices: Questions must be hard, and choices must be confusing and closely related.
3. Scope: Cover all important concepts within the topic without repetition.
4. No Extra Text: Do not add any introductory or concluding text outside of the [START Q]...[END Q] blocks.`;
  };

  const copyPrompt = async () => {
    try {
      await navigator.clipboard.writeText(generatePrompt());
      setMessage({ type: 'success', text: 'Prompt copied to clipboard!' });
      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to copy prompt' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleInputChange = (value: string) => {
    setInput(value);
    
    if (isRealTimeParsing && value.trim()) {
      // Real-time parsing preview
      try {
        const questions = parseQuestions(value, subject);
        if (questions.length > 0) {
          setMessage({ 
            type: 'success', 
            text: `Preview: ${questions.length} valid question(s) detected` 
          });
        }
      } catch (error) {
        // Silently handle parsing errors during real-time preview
      }
    }
  };

  const handleSave = () => {
    if (!input.trim()) {
      setMessage({ type: 'error', text: 'Please enter questions before saving.' });
      setTimeout(() => setMessage(null), 3000);
      return;
    }

    try {
      const questions = parseQuestions(input, subject);
      
      if (questions.length === 0) {
        setMessage({ type: 'error', text: 'No valid questions found. Please check the format.' });
        setTimeout(() => setMessage(null), 3000);
        return;
      }

      saveQuestions(questions);
      setParsedCount(questions.length);
      setMessage({ 
        type: 'success', 
        text: `Successfully saved ${questions.length} question(s) for ${subject}!` 
      });
      setInput('');
      
      setTimeout(() => setMessage(null), 5000);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to parse questions. Please check the format.' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-slate-600 hover:text-slate-800 transition-colors mr-4"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>
        <h1 className="text-2xl font-bold text-slate-800">
          Add Questions - {subject}
        </h1>
      </div>

      {/* Message Display */}
      {message && (
        <div className={`mb-6 p-4 rounded-lg flex items-center space-x-3 ${
          message.type === 'success' 
            ? 'bg-green-50 border border-green-200 text-green-800' 
            : 'bg-red-50 border border-red-200 text-red-800'
        }`}>
          {message.type === 'success' ? (
            <CheckCircle className="w-5 h-5 text-green-600" />
          ) : (
            <AlertCircle className="w-5 h-5 text-red-600" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Prompt Section */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-slate-800">Question Generation Prompt</h2>
              <button
                onClick={copyPrompt}
                className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
              >
                <Copy className="w-4 h-4" />
                <span>Copy Prompt</span>
              </button>
            </div>
            <p className="text-sm text-slate-600 mb-4">
              Copy this prompt and use it with your AI assistant to generate questions in the correct format:
            </p>
          </div>
          <div className="p-6">
            <div className="bg-slate-50 p-4 rounded-lg border text-sm font-mono overflow-auto max-h-96">
              <pre className="whitespace-pre-wrap text-slate-700">
                {generatePrompt()}
              </pre>
            </div>
          </div>
        </div>

        {/* Input Section */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200">
          <div className="p-6 border-b border-slate-200">
            <h2 className="text-lg font-semibold text-slate-800 mb-2">Paste Generated Questions</h2>
            <p className="text-sm text-slate-600">
              Paste the AI-generated questions here following the exact format shown in the prompt.
            </p>
          </div>
          <div className="p-6">
            <textarea
              value={input}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder="Paste your questions here following the [START Q]...[END Q] format..."
              className="w-full h-96 p-4 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none font-mono text-sm"
            />
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center space-x-4">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={isRealTimeParsing}
                    onChange={(e) => setIsRealTimeParsing(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm text-slate-600">Real-time parsing preview</span>
                </label>
              </div>
              <button
                onClick={handleSave}
                disabled={!input.trim()}
                className="flex items-center space-x-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Save Questions</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Format Example */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
        <h3 className="font-semibold text-blue-800 mb-3">Format Requirements</h3>
        <div className="text-sm text-blue-700 space-y-2">
          <p>• Each question must start with <code className="bg-blue-100 px-1 rounded">[START Q]</code> and end with <code className="bg-blue-100 px-1 rounded">[END Q]</code></p>
          <p>• Include all fields: QUESTION, OPTION A-D, ANSWER, EXPLANATION, TAG</p>
          <p>• Answer must be a single letter: A, B, C, or D</p>
          <p>• Parser is case-insensitive and handles spacing variations</p>
          <p>• Focus on clinical scenarios and high-difficulty questions</p>
        </div>
      </div>
    </div>
  );
}

export default QuestionInput;