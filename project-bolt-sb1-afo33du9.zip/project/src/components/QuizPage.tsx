import React, { useState } from 'react';
import { Subject } from '../types';
import { SUBJECTS } from '../constants/subjects';
import QuestionInput from './QuestionInput';
import QuizInterface from './QuizInterface';
import { ChevronRight, BookOpen } from 'lucide-react';

function QuizPage() {
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [showQuestionInput, setShowQuestionInput] = useState(false);

  if (showQuestionInput && selectedSubject) {
    return (
      <QuestionInput 
        subject={selectedSubject}
        onBack={() => setShowQuestionInput(false)}
      />
    );
  }

  if (selectedSubject) {
    return (
      <QuizInterface 
        subject={selectedSubject}
        onBack={() => setSelectedSubject(null)}
      />
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-4">Create or Take a Medical Quiz</h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Select a subject to begin. You can either input new questions or take a quiz with existing questions.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {SUBJECTS.map((subject) => (
          <button
            key={subject}
            onClick={() => setSelectedSubject(subject)}
            className="group bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md hover:border-blue-200 transition-all duration-200 text-left"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <BookOpen className="w-5 h-5 text-blue-600" />
              </div>
              <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-blue-600 transition-colors" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">{subject}</h3>
            <p className="text-sm text-slate-600">
              Create questions or take quiz
            </p>
          </button>
        ))}
      </div>

      {selectedSubject && (
        <div className="mt-8 bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h2 className="text-xl font-semibold text-slate-800 mb-4">
            {selectedSubject} - Choose Your Action
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button
              onClick={() => setShowQuestionInput(true)}
              className="bg-blue-600 text-white p-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center space-x-2"
            >
              <BookOpen className="w-5 h-5" />
              <span>Input New Questions</span>
            </button>
            <button
              onClick={() => {/* This will be handled by QuizInterface */}}
              className="bg-teal-600 text-white p-4 rounded-lg hover:bg-teal-700 transition-colors duration-200 flex items-center justify-center space-x-2"
            >
              <ChevronRight className="w-5 h-5" />
              <span>Take Quiz</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default QuizPage;