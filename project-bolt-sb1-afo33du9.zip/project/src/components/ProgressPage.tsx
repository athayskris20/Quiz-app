import React, { useState, useEffect } from 'react';
import { QuizResult, Subject } from '../types';
import { getQuizResults, getResultsBySubject } from '../utils/localStorage';
import { SUBJECTS } from '../constants/subjects';
import { BarChart3, TrendingUp, Clock, Target, Calendar } from 'lucide-react';

function ProgressPage() {
  const [results, setResults] = useState<QuizResult[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<Subject | 'all'>('all');

  useEffect(() => {
    const allResults = getQuizResults();
    setResults(allResults);
  }, []);

  const filteredResults = selectedSubject === 'all' 
    ? results 
    : getResultsBySubject(selectedSubject);

  const getSubjectStats = (subject: Subject) => {
    const subjectResults = getResultsBySubject(subject);
    if (subjectResults.length === 0) return null;

    const totalQuizzes = subjectResults.length;
    const averageScore = Math.round(
      subjectResults.reduce((sum, r) => sum + r.percentage, 0) / totalQuizzes
    );
    const bestScore = Math.max(...subjectResults.map(r => r.percentage));
    const recentScore = subjectResults[subjectResults.length - 1]?.percentage || 0;

    return { totalQuizzes, averageScore, bestScore, recentScore };
  };

  const getOverallStats = () => {
    if (results.length === 0) return null;

    const totalQuizzes = results.length;
    const averageScore = Math.round(
      results.reduce((sum, r) => sum + r.percentage, 0) / totalQuizzes
    );
    const bestScore = Math.max(...results.map(r => r.percentage));
    const totalTimeSpent = results.reduce((sum, r) => sum + r.timeSpent, 0);

    return { totalQuizzes, averageScore, bestScore, totalTimeSpent };
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${secs}s`;
    } else {
      return `${secs}s`;
    }
  };

  const getScoreColor = (percentage: number) => {
    if (percentage >= 80) return 'text-green-600';
    if (percentage >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const overallStats = getOverallStats();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-4">Progress Dashboard</h1>
        <p className="text-lg text-slate-600">Track your performance across all medical subjects</p>
      </div>

      {/* Overall Stats */}
      {overallStats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <BarChart3 className="w-8 h-8 text-blue-600" />
              <span className="text-2xl font-bold text-slate-800">{overallStats.totalQuizzes}</span>
            </div>
            <p className="text-sm text-slate-600">Total Quizzes</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <Target className="w-8 h-8 text-teal-600" />
              <span className={`text-2xl font-bold ${getScoreColor(overallStats.averageScore)}`}>
                {overallStats.averageScore}%
              </span>
            </div>
            <p className="text-sm text-slate-600">Average Score</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-8 h-8 text-green-600" />
              <span className="text-2xl font-bold text-green-600">{overallStats.bestScore}%</span>
            </div>
            <p className="text-sm text-slate-600">Best Score</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <Clock className="w-8 h-8 text-orange-600" />
              <span className="text-2xl font-bold text-slate-800">
                {formatTime(overallStats.totalTimeSpent)}
              </span>
            </div>
            <p className="text-sm text-slate-600">Total Study Time</p>
          </div>
        </div>
      )}

      {/* Subject Filter */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-slate-700 mb-2">
          Filter by Subject:
        </label>
        <select
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value as Subject | 'all')}
          className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">All Subjects</option>
          {SUBJECTS.map(subject => (
            <option key={subject} value={subject}>{subject}</option>
          ))}
        </select>
      </div>

      {/* Subject Performance Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Subject Stats */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-xl font-semibold text-slate-800 mb-4">Subject Performance</h2>
          
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {SUBJECTS.map(subject => {
              const stats = getSubjectStats(subject);
              if (!stats) {
                return (
                  <div key={subject} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <span className="font-medium text-slate-600">{subject}</span>
                    <span className="text-sm text-slate-400">No data</span>
                  </div>
                );
              }

              return (
                <div key={subject} className="p-4 border border-slate-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-slate-800">{subject}</span>
                    <span className={`font-bold ${getScoreColor(stats.averageScore)}`}>
                      {stats.averageScore}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-slate-600">
                    <span>{stats.totalQuizzes} quiz{stats.totalQuizzes !== 1 ? 'es' : ''}</span>
                    <span>Best: {stats.bestScore}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Results */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-xl font-semibold text-slate-800 mb-4">Recent Quiz Results</h2>
          
          {filteredResults.length === 0 ? (
            <div className="text-center py-8">
              <BarChart3 className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <p className="text-slate-600">No quiz results yet</p>
              <p className="text-sm text-slate-500">Take your first quiz to see progress here</p>
            </div>
          ) : (
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {filteredResults
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .slice(0, 10)
                .map((result) => (
                  <div key={result.id} className="p-4 border border-slate-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-slate-800">{result.subject}</span>
                      <span className={`font-bold ${getScoreColor(result.percentage)}`}>
                        {result.score}/{result.totalQuestions} ({result.percentage}%)
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm text-slate-600">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{formatDate(result.date)}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{formatTime(result.timeSpent)}</span>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>

      {/* Performance Chart Visualization */}
      {filteredResults.length > 0 && (
        <div className="mt-8 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-xl font-semibold text-slate-800 mb-4">
            Performance Trend - Last {Math.min(filteredResults.length, 10)} Quizzes
          </h2>
          
          <div className="space-y-4">
            <div className="h-64 flex items-end justify-center space-x-1 bg-slate-50 rounded-lg p-4 overflow-x-auto">
              {filteredResults
                .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                .slice(-10)
                .map((result, index) => (
                  <div key={result.id} className="flex flex-col items-center min-w-0">
                    <div
                      className={`w-6 rounded-t transition-all duration-300 ${
                        result.percentage >= 80 ? 'bg-green-500' :
                        result.percentage >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ height: `${Math.max((result.percentage / 100) * 200, 8)}px` }}
                      title={`${result.percentage}% - ${formatDate(result.date)}`}
                    />
                    <span className="text-xs text-slate-600 mt-1 transform -rotate-45 origin-top-left">
                      {formatDate(result.date).split(' ')[0]}
                    </span>
                    <span className="text-xs font-medium text-slate-700 mt-1">
                      {result.percentage}%
                    </span>
                  </div>
                ))}
            </div>
            
            <div className="flex items-center justify-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-green-500 rounded"></div>
                <span className="text-slate-600">≥80%</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                <span className="text-slate-600">60-79%</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-red-500 rounded"></div>
                <span className="text-slate-600">&lt; 60%</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ProgressPage;