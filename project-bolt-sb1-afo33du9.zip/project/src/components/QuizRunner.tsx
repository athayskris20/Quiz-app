import React, { useState, useEffect } from 'react';
import { Question, Subject, QuizResult } from '../types';
import { saveQuizResult } from '../utils/localStorage';
import { formatTime } from '../utils/timer';
import { ArrowLeft, Clock, CheckCircle, XCircle, Eye } from 'lucide-react';

interface QuizRunnerProps {
  questions: Question[];
  subject: Subject;
  onComplete: () => void;
  onBack: () => void;
}

function QuizRunner({ questions, subject, onComplete, onBack }: QuizRunnerProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<('A' | 'B' | 'C' | 'D' | null)[]>(
    new Array(questions.length).fill(null)
  );
  const [timeLeft, setTimeLeft] = useState(45);
  const [totalTimeSpent, setTotalTimeSpent] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<'A' | 'B' | 'C' | 'D' | null>(null);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [showReview, setShowReview] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === questions.length - 1;

  // Timer effect
  useEffect(() => {
    if (quizCompleted || showReview) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleTimeUp();
          return 0;
        }
        return prev - 1;
      });
      setTotalTimeSpent((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [currentQuestionIndex, quizCompleted, showReview]);

  const handleTimeUp = () => {
    if (!showFeedback) {
      const newAnswers = [...userAnswers];
      newAnswers[currentQuestionIndex] = selectedAnswer;
      setUserAnswers(newAnswers);
      
      if (isLastQuestion) {
        completeQuiz(newAnswers);
      } else {
        goToNextQuestion();
      }
    }
  };

  const handleAnswerSelect = (answer: 'A' | 'B' | 'C' | 'D') => {
    if (showFeedback) return;
    
    setSelectedAnswer(answer);
    const newAnswers = [...userAnswers];
    newAnswers[currentQuestionIndex] = answer;
    setUserAnswers(newAnswers);
    
    setShowFeedback(true);
    setShowExplanation(false);
    
    // Auto-advance after 3 seconds
    setTimeout(() => {
      if (isLastQuestion) {
        completeQuiz(newAnswers);
      } else {
        goToNextQuestion();
      }
    }, 3000);
  };

  const goToNextQuestion = () => {
    setCurrentQuestionIndex((prev) => prev + 1);
    setSelectedAnswer(null);
    setShowFeedback(false);
    setShowExplanation(false);
    setTimeLeft(45);
  };

  const completeQuiz = (finalAnswers: ('A' | 'B' | 'C' | 'D' | null)[]) => {
    const score = finalAnswers.reduce((acc, answer, index) => {
      return acc + (answer === questions[index].answer ? 1 : 0);
    }, 0);
    
    const result: QuizResult = {
      id: Date.now().toString(),
      subject,
      score,
      totalQuestions: questions.length,
      percentage: Math.round((score / questions.length) * 100),
      date: new Date().toISOString(),
      timeSpent: totalTimeSpent,
      questions,
      userAnswers: finalAnswers
    };
    
    saveQuizResult(result);
    setQuizCompleted(true);
  };

  const getScoreColor = (percentage: number) => {
    if (percentage >= 80) return 'text-green-600';
    if (percentage >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (showReview) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => setShowReview(false)}
            className="flex items-center space-x-2 text-slate-600 hover:text-slate-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Results</span>
          </button>
          <h1 className="text-2xl font-bold text-slate-800">Quiz Review</h1>
        </div>

        <div className="space-y-6">
          {questions.map((question, index) => {
            const userAnswer = userAnswers[index];
            const isCorrect = userAnswer === question.answer;
            
            return (
              <div key={question.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="font-semibold text-slate-800">Question {index + 1}</h3>
                  {isCorrect ? (
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-600" />
                  )}
                </div>
                
                <p className="text-slate-700 mb-4">{question.question}</p>
                
                <div className="space-y-2 mb-4">
                  {['A', 'B', 'C', 'D'].map((option) => {
                    const optionText = question[`option${option}` as keyof Question] as string;
                    const isUserAnswer = userAnswer === option;
                    const isCorrectAnswer = question.answer === option;
                    
                    let bgClass = 'bg-slate-50';
                    let textClass = 'text-slate-700';
                    let borderClass = 'border-slate-200';
                    
                    if (isCorrectAnswer) {
                      bgClass = 'bg-green-50';
                      textClass = 'text-green-800';
                      borderClass = 'border-green-200';
                    } else if (isUserAnswer && !isCorrectAnswer) {
                      bgClass = 'bg-red-50';
                      textClass = 'text-red-800';
                      borderClass = 'border-red-200';
                    }
                    
                    return (
                      <div
                        key={option}
                        className={`p-3 rounded-lg border ${bgClass} ${borderClass}`}
                      >
                        <span className={`font-medium ${textClass}`}>
                          {option}. {optionText}
                        </span>
                      </div>
                    );
                  })}
                </div>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-medium text-blue-800 mb-2">Explanation:</h4>
                  <p className="text-blue-700">{question.explanation}</p>
                </div>
                
                <div className="mt-2 text-sm text-slate-600">
                  <span className="font-medium">Tag:</span> {question.tag}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  if (quizCompleted) {
    const score = userAnswers.reduce((acc, answer, index) => {
      return acc + (answer === questions[index].answer ? 1 : 0);
    }, 0);
    const percentage = Math.round((score / questions.length) * 100);

    return (
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 text-center">
          <div className="mb-6">
            {percentage >= 80 ? (
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
            ) : (
              <XCircle className="w-16 h-16 text-red-600 mx-auto mb-4" />
            )}
            <h2 className="text-3xl font-bold text-slate-800 mb-2">Quiz Completed!</h2>
            <p className="text-slate-600">Here are your results for {subject}</p>
          </div>

          <div className="grid grid-cols-2 gap-6 mb-8">
            <div className="bg-slate-50 p-4 rounded-lg">
              <div className={`text-3xl font-bold ${getScoreColor(percentage)}`}>
                {score}/{questions.length}
              </div>
              <div className="text-sm text-slate-600">Correct Answers</div>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <div className={`text-3xl font-bold ${getScoreColor(percentage)}`}>
                {percentage}%
              </div>
              <div className="text-sm text-slate-600">Score</div>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-slate-700">
                {formatTime(totalTimeSpent)}
              </div>
              <div className="text-sm text-slate-600">Time Spent</div>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-slate-700">
                {Math.round(totalTimeSpent / questions.length)}s
              </div>
              <div className="text-sm text-slate-600">Avg per Question</div>
            </div>
          </div>

          <div className="space-y-4">
            <button
              onClick={() => setShowReview(true)}
              className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
            >
              <Eye className="w-5 h-5" />
              <span>Review Answers & Explanations</span>
            </button>
            
            <button
              onClick={onComplete}
              className="w-full bg-slate-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-slate-700 transition-colors"
            >
              Back to Quiz Selection
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-slate-600 hover:text-slate-800 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Exit Quiz</span>
        </button>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg border">
            <Clock className="w-5 h-5 text-slate-600" />
            <span className={`font-mono text-lg ${timeLeft <= 10 ? 'text-red-600' : 'text-slate-700'}`}>
              {formatTime(timeLeft)}
            </span>
          </div>
          
          <div className="bg-white px-4 py-2 rounded-lg border">
            <span className="text-sm text-slate-600">
              {currentQuestionIndex + 1} of {questions.length}
            </span>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-8">
        <div className="bg-slate-200 h-2 rounded-full">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-medium text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
              {subject}
            </span>
            <span className="text-sm text-slate-600">
              Tag: {currentQuestion.tag}
            </span>
          </div>
          
          <h2 className="text-xl font-semibold text-slate-800 mb-6">
            {currentQuestion.question}
          </h2>
        </div>

        <div className="space-y-3">
          {['A', 'B', 'C', 'D'].map((option) => {
            const optionText = currentQuestion[`option${option}` as keyof Question] as string;
            const isSelected = selectedAnswer === option;
            const isCorrect = currentQuestion.answer === option;
            const isUserAnswer = userAnswers[currentQuestionIndex] === option;

            let buttonClass = 'w-full p-4 text-left border-2 rounded-lg transition-all duration-200 ';
            
            if (showFeedback) {
              if (isCorrect) {
                buttonClass += 'bg-green-50 border-green-500 text-green-800';
              } else if (isUserAnswer && !isCorrect) {
                buttonClass += 'bg-red-50 border-red-500 text-red-800';
              } else {
                buttonClass += 'bg-slate-50 border-slate-200 text-slate-600';
              }
            } else {
              if (isSelected) {
                buttonClass += 'bg-blue-50 border-blue-500 text-blue-800';
              } else {
                buttonClass += 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300';
              }
            }

            return (
              <button
                key={option}
                onClick={() => handleAnswerSelect(option)}
                disabled={showFeedback}
                className={buttonClass}
              >
                <span className="font-medium mr-3">{option}.</span>
                {optionText}
              </button>
            );
          })}
        </div>

        {showFeedback && (
          <div className="mt-6 space-y-4">
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
            <div className="flex items-center space-x-2 mb-2">
              {selectedAnswer === currentQuestion.answer ? (
                <>
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="font-medium text-green-800">Correct!</span>
                </>
              ) : (
                <>
                  <XCircle className="w-5 h-5 text-red-600" />
                  <span className="font-medium text-red-800">
                    Incorrect. The correct answer is {currentQuestion.answer}.
                  </span>
                </>
              )}
            </div>
            <p className="text-sm text-slate-600">
              {isLastQuestion ? 'Quiz completed! Redirecting to results...' : 'Moving to next question...'}
            </p>
          </div>
            
            {!showExplanation && (
              <button
                onClick={() => setShowExplanation(true)}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm"
              >
                Show Explanation
              </button>
            )}
            
            {showExplanation && (
              <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                <h4 className="font-medium text-blue-800 mb-2">Explanation:</h4>
                <p className="text-blue-700">{currentQuestion.explanation}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default QuizRunner;