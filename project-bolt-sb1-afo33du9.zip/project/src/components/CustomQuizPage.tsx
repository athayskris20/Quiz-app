import React, { useState, useEffect } from 'react';
import { Subject } from '../types';
import { SUBJECTS } from '../constants/subjects';
import { getQuestionsBySubject, getUniqueTagsBySubject, getQuestionsByTags } from '../utils/localStorage';
import { Play, Filter, BookOpen } from 'lucide-react';
import QuizRunner from './QuizRunner';

function CustomQuizPage() {
  const [selectedSubject, setSelectedSubject] = useState<Subject | ''>('');
  const [availableTags, setAvailableTags] = useState<string[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [numberOfQuestions, setNumberOfQuestions] = useState(10);
  const [showQuiz, setShowQuiz] = useState(false);
  const [availableQuestions, setAvailableQuestions] = useState(0);

  useEffect(() => {
    if (selectedSubject) {
      const tags = getUniqueTagsBySubject(selectedSubject);
      setAvailableTags(tags);
      setSelectedTags([]);
      updateAvailableQuestions(selectedSubject, []);
    }
  }, [selectedSubject]);

  useEffect(() => {
    if (selectedSubject) {
      updateAvailableQuestions(selectedSubject, selectedTags);
    }
  }, [selectedTags, selectedSubject]);

  const updateAvailableQuestions = (subject: Subject, tags: string[]) => {
    const questions = getQuestionsByTags(subject, tags);
    setAvailableQuestions(questions.length);
    setNumberOfQuestions(Math.min(10, questions.length));
  };

  const handleTagToggle = (tag: string) => {
    setSelectedTags(prev => {
      if (prev.includes(tag)) {
        return prev.filter(t => t !== tag);
      } else {
        return [...prev, tag];
      }
    });
  };

  const startCustomQuiz = () => {
    if (!selectedSubject || availableQuestions === 0) return;
    setShowQuiz(true);
  };

  const getRandomQuestions = () => {
    if (!selectedSubject) return [];
    
    const questions = getQuestionsByTags(selectedSubject, selectedTags);
    const shuffled = [...questions].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, numberOfQuestions);
  };

  if (showQuiz && selectedSubject) {
    return (
      <QuizRunner
        questions={getRandomQuestions()}
        subject={selectedSubject}
        onComplete={() => setShowQuiz(false)}
        onBack={() => setShowQuiz(false)}
      />
    );
  }

  const getSubjectQuestionCount = (subject: Subject) => {
    return getQuestionsBySubject(subject).length;
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-4">Custom Quiz Builder</h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Create a personalized quiz by selecting subject, topics, and number of questions from your saved question bank
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Subject Selection */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-blue-100 p-2 rounded-lg">
              <BookOpen className="w-5 h-5 text-blue-600" />
            </div>
            <h2 className="text-xl font-semibold text-slate-800">Select Subject</h2>
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {SUBJECTS.map((subject) => {
              const questionCount = getSubjectQuestionCount(subject);
              return (
                <button
                  key={subject}
                  onClick={() => setSelectedSubject(subject)}
                  disabled={questionCount === 0}
                  className={`w-full p-3 text-left rounded-lg border-2 transition-all duration-200 ${
                    selectedSubject === subject
                      ? 'bg-blue-50 border-blue-500 text-blue-800'
                      : questionCount === 0
                      ? 'bg-slate-50 border-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{subject}</span>
                    <span className="text-sm">
                      {questionCount} question{questionCount !== 1 ? 's' : ''}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tag Selection */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-teal-100 p-2 rounded-lg">
              <Filter className="w-5 h-5 text-teal-600" />
            </div>
            <h2 className="text-xl font-semibold text-slate-800">Filter by Tags</h2>
          </div>

          {!selectedSubject ? (
            <p className="text-slate-500 text-center py-8">
              Select a subject first to see available tags
            </p>
          ) : availableTags.length === 0 ? (
            <p className="text-slate-500 text-center py-8">
              No tags available for this subject
            </p>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              <button
                onClick={() => setSelectedTags([])}
                className={`w-full p-2 text-left rounded-lg border transition-all duration-200 ${
                  selectedTags.length === 0
                    ? 'bg-teal-50 border-teal-500 text-teal-800'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span className="text-sm font-medium">All Tags</span>
              </button>

              {availableTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => handleTagToggle(tag)}
                  className={`w-full p-2 text-left rounded-lg border transition-all duration-200 ${
                    selectedTags.includes(tag)
                      ? 'bg-teal-50 border-teal-500 text-teal-800'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span className="text-sm font-medium capitalize">{tag}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Quiz Configuration */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-green-100 p-2 rounded-lg">
              <Play className="w-5 h-5 text-green-600" />
            </div>
            <h2 className="text-xl font-semibold text-slate-800">Quiz Settings</h2>
          </div>

          <div className="space-y-6">
            {/* Current Selection Summary */}
            <div className="bg-slate-50 p-4 rounded-lg">
              <h3 className="font-medium text-slate-700 mb-3">Current Selection:</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">Subject:</span>
                  <span className="font-medium">{selectedSubject || 'None selected'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Tags:</span>
                  <span className="font-medium">
                    {selectedTags.length === 0 ? 'All' : `${selectedTags.length} selected`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Available Questions:</span>
                  <span className="font-medium text-blue-600">{availableQuestions}</span>
                </div>
              </div>
            </div>

            {/* Number of Questions */}
            {selectedSubject && availableQuestions > 0 && (
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Number of Questions:
                </label>
                <select
                  value={numberOfQuestions}
                  onChange={(e) => setNumberOfQuestions(Number(e.target.value))}
                  className="w-full p-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {[5, 10, 15, 20, 25, 30].filter(n => n <= availableQuestions).map(n => (
                    <option key={n} value={n}>{n} Questions</option>
                  ))}
                  {availableQuestions <= 30 && availableQuestions > 0 && (
                    <option value={availableQuestions}>All {availableQuestions} Questions</option>
                  )}
                </select>
              </div>
            )}

            {/* Selected Tags Display */}
            {selectedTags.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Selected Tags:
                </label>
                <div className="flex flex-wrap gap-2">
                  {selectedTags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 bg-teal-100 text-teal-800 text-sm rounded-full border border-teal-200"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Start Quiz Button */}
            <button
              onClick={startCustomQuiz}
              disabled={!selectedSubject || availableQuestions === 0}
              className="w-full bg-green-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-green-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
            >
              <Play className="w-5 h-5" />
              <span>
                {!selectedSubject
                  ? 'Select a Subject First'
                  : availableQuestions === 0
                  ? 'No Questions Available'
                  : `Start ${numberOfQuestions} Question Quiz`
                }
              </span>
            </button>

            {/* Quiz Info */}
            {selectedSubject && availableQuestions > 0 && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-800 mb-2">Quiz Details:</h4>
                <div className="text-sm text-blue-700 space-y-1">
                  <p>• 45 seconds per question</p>
                  <p>• Instant feedback after each answer</p>
                  <p>• Detailed review available after completion</p>
                  <p>• Progress automatically saved</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default CustomQuizPage;