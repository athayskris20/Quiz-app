import React, { useState } from 'react';
import { BookOpen, BarChart3, Play } from 'lucide-react';
import QuizPage from './components/QuizPage';
import ProgressPage from './components/ProgressPage';
import CustomQuizPage from './components/CustomQuizPage';

type Page = 'quiz' | 'progress' | 'custom';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('quiz');

  const renderPage = () => {
    switch (currentPage) {
      case 'quiz':
        return <QuizPage />;
      case 'progress':
        return <ProgressPage />;
      case 'custom':
        return <CustomQuizPage />;
      default:
        return <QuizPage />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Navigation Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-slate-800">NEET PG Quiz Master</h1>
            </div>
            <nav className="flex space-x-1">
              <button
                onClick={() => setCurrentPage('quiz')}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 ${
                  currentPage === 'quiz'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>Quiz</span>
              </button>
              <button
                onClick={() => setCurrentPage('progress')}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 ${
                  currentPage === 'progress'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span>Progress</span>
              </button>
              <button
                onClick={() => setCurrentPage('custom')}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 ${
                  currentPage === 'custom'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
                }`}
              >
                <Play className="w-4 h-4" />
                <span>Custom Quiz</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {renderPage()}
      </main>
    </div>
  );
}

export default App;